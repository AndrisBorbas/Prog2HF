var _builds_8h =
[
    [ "Build", "class_build.html", "class_build" ],
    [ "Orders", "class_orders.html", "class_orders" ],
    [ "operator<<", "_builds_8h.html#a8dc72915bcebaea777be339661524cb9", null ],
    [ "operator<<", "_builds_8h.html#a5fb6be27fb40218ba8338cb8727178cd", null ]
];