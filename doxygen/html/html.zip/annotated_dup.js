var annotated_dup =
[
    [ "Build", "class_build.html", "class_build" ],
    [ "Case", "class_case.html", "class_case" ],
    [ "CompatibilityList", "class_compatibility_list.html", "class_compatibility_list" ],
    [ "CPU", "class_c_p_u.html", "class_c_p_u" ],
    [ "GPU", "class_g_p_u.html", "class_g_p_u" ],
    [ "HDD", "class_h_d_d.html", "class_h_d_d" ],
    [ "Inventory", "class_inventory.html", "class_inventory" ],
    [ "MOBO", "class_m_o_b_o.html", "class_m_o_b_o" ],
    [ "Orders", "class_orders.html", "class_orders" ],
    [ "Part", "class_part.html", "class_part" ],
    [ "PSU", "class_p_s_u.html", "class_p_s_u" ],
    [ "RAM", "class_r_a_m.html", "class_r_a_m" ],
    [ "SSD", "class_s_s_d.html", "class_s_s_d" ],
    [ "Storage", "class_storage.html", "class_storage" ],
    [ "String", "class_string.html", "class_string" ],
    [ "TempInput", "struct_temp_input.html", "struct_temp_input" ],
    [ "utos_ostream", "structutos__ostream.html", "structutos__ostream" ],
    [ "utos_t", "structutos__t.html", null ]
];