var class_orders =
[
    [ "Orders", "class_orders.html#aa52a641a269671bbf68637e0771e8b5d", null ],
    [ "~Orders", "class_orders.html#a12bcbd0cd430b51f65f651fddad3f662", null ],
    [ "operator[]", "class_orders.html#a9574f4521c39b8a8d7cdfd1f28b07ffb", null ],
    [ "operator[]", "class_orders.html#abae5fb4a0e7dfa2c222215850531d695", null ],
    [ "push_back", "class_orders.html#a678969b0e57fd41f4ab0cc949d4500f6", null ]
];