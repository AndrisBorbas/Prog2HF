var searchData=
[
  ['brand',['brand',['../struct_temp_input.html#ae61ec1c3c483e583e4975e5c728e4886',1,'TempInput::brand()'],['../class_part.html#ae06f2fdeb7fbbdb229a7aca151f3e341',1,'Part::brand()']]]
];
