var searchData=
[
  ['gtest_5flite',['gtest_lite',['../namespacegtest__lite.html',1,'']]]
];
