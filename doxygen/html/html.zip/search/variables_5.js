var searchData=
[
  ['os',['os',['../structutos__ostream.html#aec8d0c25d29aa2cea8ade1cfb60fb3ef',1,'utos_ostream']]]
];
