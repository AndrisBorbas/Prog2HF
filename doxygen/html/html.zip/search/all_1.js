var searchData=
[
  ['brand',['brand',['../struct_temp_input.html#ae61ec1c3c483e583e4975e5c728e4886',1,'TempInput::brand()'],['../class_part.html#ae06f2fdeb7fbbdb229a7aca151f3e341',1,'Part::brand()']]],
  ['build',['Build',['../class_build.html',1,'Build'],['../class_build.html#ab9b72c3479d483c0b452af30bb544de8',1,'Build::Build()']]],
  ['builds_2ecpp',['Builds.cpp',['../_builds_8cpp.html',1,'']]],
  ['builds_2eh',['Builds.h',['../_builds_8h.html',1,'']]]
];
