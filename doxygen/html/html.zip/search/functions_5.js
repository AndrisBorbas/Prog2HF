var searchData=
[
  ['hdd',['HDD',['../class_h_d_d.html#a375ad923cb64a11afc261fe1fac5276c',1,'HDD::HDD(String brand, String type, int price, int size, int readspeed, int writespeed, int rpm)'],['../class_h_d_d.html#a98374b087d6a74476b914dedb2de1ec4',1,'HDD::HDD(TempInput tmp)']]]
];
