var searchData=
[
  ['gtend',['GTEND',['../gtest__lite_8h.html#a20ba54bca307f985eb448f71e6896dd5',1,'gtest_lite.h']]],
  ['gtinit',['GTINIT',['../gtest__lite_8h.html#a428e5e5ea2b7f67a0b68fbf57ea0faa7',1,'gtest_lite.h']]]
];
