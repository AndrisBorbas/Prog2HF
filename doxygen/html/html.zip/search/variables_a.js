var searchData=
[
  ['utos',['utos',['../schtring_8hpp.html#a87ab25645bb130a0e89654a4ba9d2bce',1,'schtring.hpp']]]
];
