var searchData=
[
  ['flashtype',['flashtype',['../struct_temp_input.html#aca0d9830369aab845fc274c6b54ffe33',1,'TempInput']]],
  ['formfactor',['formfactor',['../struct_temp_input.html#a402c6984d9e94d4c76e460d0368613f3',1,'TempInput']]]
];
