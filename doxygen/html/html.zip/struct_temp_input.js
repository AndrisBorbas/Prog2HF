var struct_temp_input =
[
    [ "brand", "struct_temp_input.html#ae61ec1c3c483e583e4975e5c728e4886", null ],
    [ "chipset", "struct_temp_input.html#a29da394f96dae5eaa49e145207362a9c", null ],
    [ "clk", "struct_temp_input.html#aa76fe14a614fef6e9239ce2283d6b102", null ],
    [ "clname", "struct_temp_input.html#a623b1fe5692319aad5c58cbc42bedf9c", null ],
    [ "cores", "struct_temp_input.html#a9b99532e6c984fb19c34ed943a6d5750", null ],
    [ "flashtype", "struct_temp_input.html#aca0d9830369aab845fc274c6b54ffe33", null ],
    [ "formfactor", "struct_temp_input.html#a402c6984d9e94d4c76e460d0368613f3", null ],
    [ "instruction", "struct_temp_input.html#a693f4a5b4215b51144174287aecab527", null ],
    [ "multithreading", "struct_temp_input.html#ad8957d3af0ed714844abf3f37cbfc719", null ],
    [ "price", "struct_temp_input.html#a6d049ee814f00b43e1d951317261e357", null ],
    [ "readspeed", "struct_temp_input.html#a75c5e55813802a9d6af6818de81e6001", null ],
    [ "rpm", "struct_temp_input.html#a661104db14326156bbb2ffa5a7c6f468", null ],
    [ "size", "struct_temp_input.html#adfc0eb32fac7de584c3872875b452550", null ],
    [ "socket", "struct_temp_input.html#a5142af446776f87e454134511f681887", null ],
    [ "type", "struct_temp_input.html#a1a73f4b9c84caa8c463a4bad03cf433d", null ],
    [ "wattage", "struct_temp_input.html#a2764957397bba59e827c66aeb1821279", null ],
    [ "writespeed", "struct_temp_input.html#a3d5511c959e7c3531ce3bea3a6248d62", null ]
];