var class_string =
[
    [ "String", "class_string.html#a8a7ef356e05eb9b1ea1ab518baee3095", null ],
    [ "String", "class_string.html#a62a77180f8df2547e8be1313654abcee", null ],
    [ "String", "class_string.html#a09ca4f1436a83ecb1c273a836b7cd4c6", null ],
    [ "String", "class_string.html#a3c682dc983b45bdbb7f3858fe4cbf221", null ],
    [ "~String", "class_string.html#ac40b2a3fb58c2d8556f5e6ff73510036", null ],
    [ "c_str", "class_string.html#a0274f3e61533d15086816fb7f47ccb54", null ],
    [ "erase", "class_string.html#a3ce2ea55be9ec912bb2dbc88d461b479", null ],
    [ "length", "class_string.html#ad3b888edbfb3bab21d4bae4663d2211a", null ],
    [ "operator+", "class_string.html#a28a020f061e5f25317af47488bfb7de8", null ],
    [ "operator+", "class_string.html#afa169686af6b513e1f059cf2bf39695f", null ],
    [ "operator+=", "class_string.html#ac203e7c52e04bb86f62f9dd75527b361", null ],
    [ "operator--", "class_string.html#a79869b69dd0106b1b6d179f760d6527a", null ],
    [ "operator=", "class_string.html#a803e6112834d4c0cdb0da6c6a4000e6e", null ],
    [ "operator==", "class_string.html#a1006dbb8a123aed87b8edb33d5cbcee4", null ],
    [ "operator==", "class_string.html#ade9af860a809548214837e33367e8835", null ],
    [ "operator==", "class_string.html#aa50c56cbbbc9956cb359a7617f13809b", null ],
    [ "operator[]", "class_string.html#a1a7c5c39d4dafbbf8516f5058a253f1a", null ],
    [ "operator[]", "class_string.html#aaa249e62641872197679cfc7c66118c0", null ],
    [ "removeFirstX", "class_string.html#a15c07ede44c5bcfb0920e9bf63e75670", null ],
    [ "size", "class_string.html#a588c5cc9faededbb9d938662d354feed", null ]
];