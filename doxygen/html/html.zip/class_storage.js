var class_storage =
[
    [ "Storage", "class_storage.html#a502a2ec76e09d48a87da6ed1b91cdaa8", null ],
    [ "print", "class_storage.html#aa9f6ffb0fd45839b54bd4e254270445d", null ],
    [ "print", "class_storage.html#ab7ecf9e0777891b4e1a84bbf391a1cd4", null ],
    [ "readspeed", "class_storage.html#a41073842ff16961dad3903e6dd49bb0c", null ],
    [ "size", "class_storage.html#abcc80ce58a21fa884035617ee0b6cb67", null ],
    [ "writespeed", "class_storage.html#a0198a1483ccf849d48c76da88599ba8b", null ]
];