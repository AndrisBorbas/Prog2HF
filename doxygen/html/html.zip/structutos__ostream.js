var structutos__ostream =
[
    [ "os", "structutos__ostream.html#aec8d0c25d29aa2cea8ade1cfb60fb3ef", null ]
];